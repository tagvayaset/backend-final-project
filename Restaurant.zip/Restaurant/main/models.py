from django.db import models
from django.shortcuts import reverse
from django.contrib.auth.models import User
from core import settings


class Item(models.Model):
    title = models.CharField(max_length=100)
    price = models.FloatField()
    slug = models.SlugField()
    description = models.TextField(default="NONE")
    image = models.ImageField()

class OrderItem(models.Model):
    session_id = models.CharField(max_length=100, null=True)
    user = models.ForeignKey(User,
                             on_delete=models.CASCADE, null=True)
    ordered = models.BooleanField(default=False)
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)

    def __str__(self):
        return f"{self.quantity} of {self.item.title}"

    def get_total_item_price(self):
        return int(self.quantity * self.item.price)

    def get_total_discount_item_price(self):
        return self.quantity * self.item.discount_price

    def get_amount_saved(self):
        return self.get_total_item_price() - self.get_total_discount_item_price()

    def get_final_price(self):
        return self.get_total_item_price()

class Order(models.Model):
    name = models.CharField(max_length=55, null=True)
    email = models.CharField(max_length=55, null=True)
    mobile = models.CharField(max_length=16, null=True)
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    ref_code = models.CharField(max_length=20, null=True)
    start_date = models.DateField(verbose_name='Start Date')
    time = models.CharField(max_length=55, null=True)
    payment = models.BooleanField(default=False)
    items = models.ManyToManyField(OrderItem, null=True)

    def __str__(self):
        return self.user.username