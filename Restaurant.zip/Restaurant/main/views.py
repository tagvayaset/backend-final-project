import re
from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.models import User
from main.forms import CreateUserForm, CheckoutForm, CouponForm
from main.models import OrderItem, Item, Order
from django.contrib import messages, auth
from django.db.models import Q
from django.views.generic import ListView, DetailView, View
from django.utils import timezone
from django.contrib.auth.decorators import login_required



def add(request, slug):
    item = get_object_or_404(Item, slug=slug)
    order_item, created = OrderItem.objects.get_or_create(
        item=item,
        user=request.user,
        ordered=False

    )
    order_qs = Order.objects.filter(user=request.user, payment=False)[0]
    if order_qs:
        order = order_qs
        # check if the order item is in the order
        if order.items.filter(item__slug=item.slug).exists():
            order_item.quantity += 1
            order_item.save()
            messages.info(request, "This item quantity was updated.")
            return redirect("/")
        else:
            order.items.add(order_item)
            messages.info(request, "This item was added to your cart.")
            return redirect("/")
    else:
        ordered_date = timezone.now()
        order = Order.objects.create(
            user=request.user, ordered_date=ordered_date)
        order.items.add(order_item)
        messages.info(request, "This item was added to your cart.")
        return redirect("/")

def HomePage(request):
    if request.method == "POST":
        if not request.user.is_authenticated:
            redirect('/login-account')
        if len(Order.objects.get_or_create(user=request.user, payment=False, start_date=request.POST.get('start_date'))) > 0:
            return redirect("/checkout")
        order = Order.objects.get_or_create(user=request.user, payment=False, start_date=request.POST.get('start_date'))[0]
        order.save()
        return redirect('/checkout')
    context = {
        'items': Item.objects.all()
    }
    return render(request, 'main/index.html', context)

def Profile(request):
    return render(request, 'main/profile.html')


def edit_profile(request):
    form = CreateUserForm(instance=request.user)
    context = {
        'form': form
    }
    if request.method == 'POST':
        form = CreateUserForm(request.POST, instance=request.user)
        password1 = request.POST['password1']
        cnt = 0
        if len(User.objects.filter(username=request.POST['username'])) > 0 and request.POST['username'] != request.user.username:
            messages.info(request, 'User already exists')
            cnt = 1
        if len(request.POST['password1']) > 0:
            if len(request.POST['password1']) < 8:
                messages.info(request, 'Password must contain at least 8 symbols')
                cnt = 1
            if len(request.POST['password1']) and len(request.POST['password2']) and request.POST['password1'] != request.POST['password2']:
                messages.info(request, 'Password not matching')
                cnt = 1
            if len(request.POST['password1']) < 8 and request.POST['password1'] == request.POST['password2']:
                pattern = r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).+$'
                if not re.match(pattern, password1):
                    messages.info(request, "Password must contain at least 1 uppercase, 1 lowercase and one number")
                    cnt = 1
        if cnt == 1:
            return redirect('edit_profile')
        else:
            if len(request.POST['password1']) > 0 and len(request.POST['password2']) > 0:
                request.user.password1 = request.POST['password1']
                request.user.password2 = request.POST['password2']

            request.user.username = request.POST['username']
            request.user.email = request.POST['email']
            request.user.first_name = request.POST['name']
            request.user.last_name = request.POST['surname']
            request.user.save()
            messages.success(request, "Account was created successfully")
            return redirect('profile')
    return render(request, 'main/edit_profile.html', context)


def RegisterAccount(request):
    form = CreateUserForm()
    context = {'form': form}
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        print(123)
        password1 = request.POST['password1']
        cnt = 0
        if len(User.objects.filter(username=request.POST['username'])) > 0:
            messages.info(request, 'User already exists')
            cnt = 1
        if len(request.POST['password1']) < 8:
            messages.info(request, 'Password must contain at least 8 symbols')
            cnt = 1
        if request.POST['password1'] != request.POST['password2']:
            messages.info(request, 'Password not matching')
            cnt = 1
        if len(request.POST['password1']) < 8 and request.POST['password1'] == request.POST['password2']:
            pattern = r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).+$'
            if not re.match(pattern, password1):
                messages.info(request, "Password must contain at least 1 uppercase, 1 lowercase and one number")
                cnt = 1
        if cnt == 1:
            return redirect('register-account')

        else:
        # if form.is_valid():
            print(123123)
            form.save()
            messages.success(request, "Account was created successfully")
            return redirect('login-account')
    else:
        return render(request, 'main/register-account.html', context)


def LoginAccount(request):

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            return redirect('/')
        else:
            messages.info(request, 'Invalid credentials')
            return redirect('login-account')

    else:
        return render(request, 'main/login-account.html')


def LogoutAccount(request):
    auth.logout(request)
    return redirect('/')

# @login_required
class CheckoutView(View):
    def get(self, *args, **kwargs):
        order = Order.objects.filter(user=self.request.user, payment=False)[0]
        print(order)
        form = CheckoutForm()
        context = {
            'form': form,
            'couponform': CouponForm(),
            'order': order,
            'DISPLAY_COUPON_FORM': True
        }
        return render(self.request, "main/checkout.html", context)

    def post(self, request, *args, **kwargs):
        form = CheckoutForm(self.request.POST or None)
        order = Order.objects.filter(user=self.request.user, payment=False)[0]
        order.payment = True
        order.ordered_date = timezone.now()
        order.save()
        return redirect('/')
